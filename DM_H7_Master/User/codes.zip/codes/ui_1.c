//
// Created by RM UI Designer
// Static Edition
//

#include <string.h>

#include "ui_interface.h"

ui_1_frame_t ui_1_Ungroup_0;

ui_interface_line_t *ui_1_Ungroup_NewLine = (ui_interface_line_t*)&(ui_1_Ungroup_0.data[0]);

void _ui_init_1_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_1_Ungroup_0.data[i].figure_name[0] = 0;
        ui_1_Ungroup_0.data[i].figure_name[1] = 0;
        ui_1_Ungroup_0.data[i].figure_name[2] = i + 0;
        ui_1_Ungroup_0.data[i].operate_type = 1;
    }
    for (int i = 1; i < 1; i++) {
        ui_1_Ungroup_0.data[i].operate_type = 0;
    }

    ui_1_Ungroup_NewLine->figure_type = 0;
    ui_1_Ungroup_NewLine->operate_type = 1;
    ui_1_Ungroup_NewLine->layer = 0;
    ui_1_Ungroup_NewLine->color = 0;
    ui_1_Ungroup_NewLine->start_x = 480;
    ui_1_Ungroup_NewLine->start_y = 599;
    ui_1_Ungroup_NewLine->width = 1;
    ui_1_Ungroup_NewLine->end_x = 1078;
    ui_1_Ungroup_NewLine->end_y = 778;


    ui_proc_1_frame(&ui_1_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_1_Ungroup_0, sizeof(ui_1_Ungroup_0));
}

void _ui_update_1_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_1_Ungroup_0.data[i].operate_type = 2;
    }

    ui_proc_1_frame(&ui_1_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_1_Ungroup_0, sizeof(ui_1_Ungroup_0));
}

void _ui_remove_1_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_1_Ungroup_0.data[i].operate_type = 3;
    }

    ui_proc_1_frame(&ui_1_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_1_Ungroup_0, sizeof(ui_1_Ungroup_0));
}

ui_string_frame_t ui_1_Ungroup_1;
ui_interface_string_t* ui_1_Ungroup_NewText = &(ui_1_Ungroup_1.option);

void _ui_init_1_Ungroup_1() {
    ui_1_Ungroup_1.option.figure_name[0] = 0;
    ui_1_Ungroup_1.option.figure_name[1] = 0;
    ui_1_Ungroup_1.option.figure_name[2] = 1;
    ui_1_Ungroup_1.option.operate_type = 1;

    ui_1_Ungroup_NewText->figure_type = 7;
    ui_1_Ungroup_NewText->operate_type = 1;
    ui_1_Ungroup_NewText->layer = 0;
    ui_1_Ungroup_NewText->color = 0;
    ui_1_Ungroup_NewText->start_x = 173;
    ui_1_Ungroup_NewText->start_y = 580;
    ui_1_Ungroup_NewText->width = 6;
    ui_1_Ungroup_NewText->font_size = 60;
    ui_1_Ungroup_NewText->str_length = 4;
    strcpy(ui_1_Ungroup_NewText->string, "Text");


    ui_proc_string_frame(&ui_1_Ungroup_1);
    SEND_MESSAGE((uint8_t *) &ui_1_Ungroup_1, sizeof(ui_1_Ungroup_1));
}

void _ui_update_1_Ungroup_1() {
    ui_1_Ungroup_1.option.operate_type = 2;

    ui_proc_string_frame(&ui_1_Ungroup_1);
    SEND_MESSAGE((uint8_t *) &ui_1_Ungroup_1, sizeof(ui_1_Ungroup_1));
}

void _ui_remove_1_Ungroup_1() {
    ui_1_Ungroup_1.option.operate_type = 3;

    ui_proc_string_frame(&ui_1_Ungroup_1);
    SEND_MESSAGE((uint8_t *) &ui_1_Ungroup_1, sizeof(ui_1_Ungroup_1));
}

void ui_init_1_Ungroup() {
    _ui_init_1_Ungroup_0();
    _ui_init_1_Ungroup_1();
}

void ui_update_1_Ungroup() {
    _ui_update_1_Ungroup_0();
    _ui_update_1_Ungroup_1();
}

void ui_remove_1_Ungroup() {
    _ui_remove_1_Ungroup_0();
    _ui_remove_1_Ungroup_1();
}

