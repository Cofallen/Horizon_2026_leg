//
// Created by RM UI Designer
// Static Edition
//

#ifndef UI_default_H
#define UI_default_H

#include "ui_interface.h"

extern ui_interface_line_t *ui_default_Ungroup_NewLine;

void ui_init_default_Ungroup();
void ui_update_default_Ungroup();
void ui_remove_default_Ungroup();


#endif // UI_default_H
