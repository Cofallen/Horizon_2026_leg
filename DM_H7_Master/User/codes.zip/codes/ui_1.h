//
// Created by RM UI Designer
// Static Edition
//

#ifndef UI_1_H
#define UI_1_H

#include "ui_interface.h"

extern ui_interface_line_t *ui_1_Ungroup_NewLine;
extern ui_interface_string_t *ui_1_Ungroup_NewText;

void ui_init_1_Ungroup();
void ui_update_1_Ungroup();
void ui_remove_1_Ungroup();


#endif // UI_1_H
