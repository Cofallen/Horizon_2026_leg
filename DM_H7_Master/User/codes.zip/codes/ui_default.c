//
// Created by RM UI Designer
// Static Edition
//

#include <string.h>

#include "ui_interface.h"

ui_1_frame_t ui_default_Ungroup_0;

ui_interface_line_t *ui_default_Ungroup_NewLine = (ui_interface_line_t*)&(ui_default_Ungroup_0.data[0]);

void _ui_init_default_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_default_Ungroup_0.data[i].figure_name[0] = 1;
        ui_default_Ungroup_0.data[i].figure_name[1] = 0;
        ui_default_Ungroup_0.data[i].figure_name[2] = i + 0;
        ui_default_Ungroup_0.data[i].operate_type = 1;
    }
    for (int i = 1; i < 1; i++) {
        ui_default_Ungroup_0.data[i].operate_type = 0;
    }

    ui_default_Ungroup_NewLine->figure_type = 0;
    ui_default_Ungroup_NewLine->operate_type = 1;
    ui_default_Ungroup_NewLine->layer = 0;
    ui_default_Ungroup_NewLine->color = 0;
    ui_default_Ungroup_NewLine->start_x = 1219;
    ui_default_Ungroup_NewLine->start_y = 343;
    ui_default_Ungroup_NewLine->width = 1;
    ui_default_Ungroup_NewLine->end_x = 714;
    ui_default_Ungroup_NewLine->end_y = 716;


    ui_proc_1_frame(&ui_default_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_default_Ungroup_0, sizeof(ui_default_Ungroup_0));
}

void _ui_update_default_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_default_Ungroup_0.data[i].operate_type = 2;
    }

    ui_proc_1_frame(&ui_default_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_default_Ungroup_0, sizeof(ui_default_Ungroup_0));
}

void _ui_remove_default_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_default_Ungroup_0.data[i].operate_type = 3;
    }

    ui_proc_1_frame(&ui_default_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_default_Ungroup_0, sizeof(ui_default_Ungroup_0));
}


void ui_init_default_Ungroup() {
    _ui_init_default_Ungroup_0();
}

void ui_update_default_Ungroup() {
    _ui_update_default_Ungroup_0();
}

void ui_remove_default_Ungroup() {
    _ui_remove_default_Ungroup_0();
}

