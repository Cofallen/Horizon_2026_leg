//
// Created by RM UI Designer
// Static Edition
//

#ifndef UI_H
#define UI_H
#ifdef __cplusplus
extern "C" {
#endif

#include "ui_interface.h"

#include "ui_1.h"

void ui_init_1_Ungroup();
void ui_update_1_Ungroup();
void ui_remove_1_Ungroup();
#include "ui_default.h"

void ui_init_default_Ungroup();
void ui_update_default_Ungroup();
void ui_remove_default_Ungroup();

#ifdef __cplusplus
}
#endif

#endif // UI_H
